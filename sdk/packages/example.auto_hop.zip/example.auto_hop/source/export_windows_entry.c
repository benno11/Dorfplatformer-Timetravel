/* The exported sample has no CRT, constructors, TLS, or OS imports. */
unsigned long _tls_index = 0;
#if defined(__i386__)
int __attribute__((stdcall)) _DllMainCRTStartup(void* module, unsigned long reason, void* reserved)
#else
int _DllMainCRTStartup(void* module, unsigned long reason, void* reserved)
#endif
{ (void)module; (void)reason; (void)reserved; return 1; }
#if defined(__i386__)
#include "df_mod.h"
extern int32_t DF_MOD_CALL df_mod_load(const DFModContext*, DFModCallbacks*);
int32_t DF_MOD_CALL exported_entry(const DFModContext*, DFModCallbacks*) __asm__("df_mod_load");
int32_t DF_MOD_CALL exported_entry(const DFModContext* context, DFModCallbacks* callbacks)
{ return df_mod_load(context, callbacks); }
#endif
