AUTO HOP 1.0.0 — NATIVE MOD API 1.0

Automatically jumps whenever the player lands.
Requires the full edition with the native mod loader (game commit 9060f969 or newer).

ANDROID
Settings > Mods > Import Mod ZIP: select this ZIP.
Scan for Installed Mods, then fully restart the game.
The loader chooses the library matching your device automatically.

DESKTOP (WINDOWS / LINUX / MACOS)
Extract the example.auto_hop folder into the game's mods folder.
Find that folder using Settings > Mods > Open Mods Folder.
Fully restart the game. The Mods menu should show Auto Hop as Loaded.
Disable it in Settings > Mods and restart to turn off automatic jumping.

Included binaries: Windows x64/x86, Linux x64/ARM64, macOS x64/ARM64,
and Android ARM64/ARMv7/x64/x86. Native gameplay was verified on Linux x64;
other platform binaries have been cross-compiled and structurally checked.

Source and SDK: source/sdk/. From source/, rebuild using:
  cmake -S sdk/example -B build
  cmake --build build --config Release
The prebuilt libraries need no third-party runtime libraries. macOS uses the standard system libSystem; the other builds have no OS runtime imports.
The Windows cross-build used source/export_windows_entry.c for its minimal DLL entry.
SHA256SUMS lists hashes of all packaged files except SHA256SUMS itself.
